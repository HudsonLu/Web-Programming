function addNumbers(numbers) {
  return numbers.reduce((sum, num) => sum + num, 0);
}


function findMaxNumber() { 
  return Math.max(...arguments);
}


function addOnlyNumbers(arr) {
  let sum = 0;
  for (let i = 0; i < arr.length; i++) {
    const num = parseFloat(arr[i]);
    if (!isNaN(num)) {
      sum += num;
    }
  }
  return sum;
}


function getDigits(str) {
  
  const digits = str.match(/\d+/g);
  if (!digits) {
    return '';
  }
  return digits.join('');
}


function reverseString(str) {
  return str.split('').reverse().join('');
}


function getCurrentDate() {

  const date = new Date();
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });
}
