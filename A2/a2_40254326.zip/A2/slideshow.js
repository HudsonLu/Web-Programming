const images = [
    'slide1_picture.webp',
    'slide2_picture.webp',
    'slide3_picture.webp',
    'slide4_picture.webp'
  ];
  
  let index = 0;
  const slideshow = document.getElementById('slideshow');
  const prevLink = document.getElementById('prev');
  const nextLink = document.getElementById('next');
  
  function showImage() {
    slideshow.src = images[index];
  }
  
  function nextImage() {
    index= (index + 1) % images.length;
    showImage();
  }
  
  function prevImage() {
    index = (index - 1 + images.length) % images.length;
    showImage();
  }
  
  prevLink.addEventListener('click', prevImage);
  nextLink.addEventListener('click', nextImage);
  showImage();
  