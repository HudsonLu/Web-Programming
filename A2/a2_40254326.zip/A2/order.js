function calculateTotal(event) {
	event.preventDefault(); 
	const item1 = parseInt(document.getElementById("item1").value);
	const price1 = 19.99;
	const item2 = parseInt(document.getElementById("item2").value);
	const price2 = 86.00;
	const item3 = parseInt(document.getElementById("item3").value);
	const price3 = 55.00;

	if (isNaN(item1) || isNaN(item2) || isNaN(item3) ) {
		alert("Please enter valid integers for item quantities and prices.");	
	}

	const total = item1 * price1 + item2 * price2 + item3 * price3;

	const sum1 = item1 * price1;
	const sum2 = item2 * price2;
	const sum3 = item3 * price3;

	document.getElementById("sum1").innerHTML = "<h4>"+"Basic Web Programming (Quantity = "+item1+"): $"+sum1.toFixed(2)+"</h4>";
	document.getElementById("sum2").innerHTML = "<h4>"+"Intro to PHP(Quantity = "+item2+"): $"+sum2.toFixed(2)+"</h4>";
	document.getElementById("sum3").innerHTML = "<h4>"+"Advanced JQuery(Quantity = "+item3+"): $"+sum3.toFixed(2)+"</h4>";
	document.getElementById("total").innerHTML = "<h4>"+"Final Total: $"+total.toFixed(2)+"</h4>";


}
