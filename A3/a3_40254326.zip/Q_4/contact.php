<!DOCTYPE html>
<html lang=en>
<head>
  <meta charset="UTF-8">
  <title> Question 4 </title> 
  <link rel = "stylesheet" href="format.css" >

</head>


<body>
  <?php include('header.php'); ?>
  <div class="side-menu">
    <ul>
      <li> <h3> Navigation </h3></li>
      <li><a href="index.php"> Home </a></li>
      <li><a href="create-account.php">Create An Account </a></li>
      <li><a href="find-pet.php"> Find a Cat/Dog </a></li>
      <li><a href="dog-care.php"> Dog Care </a></li>
      <li><a href="cat-care.php"> Cat Care </a></li>
      <li><a href="give-away.php"> Have a Pet to Give Away </a></li>
      <li><a class="active" href="contact.php"> Contact Us </a></li>
    </ul>
  </div>

  <div class="content">
    <h3>Contact Us</h3>
<pre>
    Name: Hudson Xingcheng Lu
    Student ID: 40254326
    Email: lu_hudso@live.concordia.ca


</pre>
</div>

<?php include('footer.php'); ?>
<script src="Q_7_JavaScript.js"></script>
</body>


</html>