<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>footer</title>
    <link rel = "stylesheet" href="format.css" >
  </head>
  <body>


<div class="footer">
        <a href="index.php"> Privacy/Disclaimer Statement </a>
</div>
<script src="Q_7_JavaScript.js"></script>
</body>
</html>