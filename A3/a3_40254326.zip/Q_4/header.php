<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>header</title>
    <link rel = "stylesheet" href="format.css" >
  </head>
  <body>
    
  <header>
    <table>
        <tr>
            <td>
                <a href="https://jstor.org/stable/community.29561881">
                <img src="Cat.jpg" alt= "cat" width = 100 height = 100 >
                </a>
            </td>
            <td>
              <a href = "index.php" ><h1>Adopt a Cat/Dog</h1></a>
            </td>
            <td></td><td></td><td></td><td></td><td></td>
            <th> <br> <span id="current-date"><?php echo date('l, F jS, Y h:i:s A'); ?></span>  </th>
        </tr>
   </table>
      <!--
        Image cited:
Cats : [Cats with Bowl]. Poulton 79 London, 2017-07-27. JSTOR, https://jstor.org/stable/community.29561881. Accessed 11 Feb. 2023.
-->
</header>
<script src="Q_7_JavaScript.js"></script>
</body>
</html>